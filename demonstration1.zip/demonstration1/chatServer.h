#include <string> 
#include "Socket.h"

using namespace std; 

namespace cs457 
{
    class chatUser 
    {
    public: 



    private:

        string nickName; 
        string password; 
        //what rooms am I in now?
    tcpUserSocket userSocket; 



    };

    class chatRooms
    {
        
    };

}