# CppSocketWraper
This is basic C++ wrapper for Posix Socket. It has been tested in Ubuntu 18.04 -- it can be improved. 

License is GNU General Public License's Version 3.  

Project1-Skeleton contains the code. Read the .vscode folder as it has my settings. Change them as needed. 

